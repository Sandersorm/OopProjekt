package Projekt;

import javafx.event.ActionEvent;
import org.w3c.dom.Text;

import java.awt.*;
import java.util.Scanner;

public class Controller extends Keegel {


        Mängija mängija = new Mängija("mark", "tutt", 29);
        public void pressButton1 (ActionEvent event) {
            int arv = 1;

        }
        public void pressButton2 (ActionEvent event) {
            int arv = 2;
        }
        public void pressButton3 (ActionEvent event) {
            int arv = 3;
        }
        public void pressButton4 (ActionEvent event) {
            int arv = 4;
        }

        public void mängi (ActionEvent event) {
            System.out.println(mängija.toString());
        }
    }
